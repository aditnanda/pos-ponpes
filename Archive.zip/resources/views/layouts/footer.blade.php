<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.1
    </div>
    <strong>Program Hibah Pengabdian Masyarakat Dari Direktur Riset, Teknologi, dan Pengabdian Kepada Masyarakat (DRTPM) Kemendikbudristek - 2022
</footer>